#!/usr/bin/env python3
"""One-click launcher for the bundled Luau deobfuscator.

Opens a .lua/.luau picker, runs the normal detector/devirtualizer, and writes
`deobfuscated.lua` beside the selected input. If the runtime is missing,
offer to build the patched Luau runtime.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEOB = ROOT / "deobf" / "deob.py"
BIN = ROOT / "deobf" / "bin"


def choose_file() -> Path | None:
    # GUI picker when Tk is available.
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.update()
        path = filedialog.askopenfilename(
            title="Select an obfuscated Luau/Lua script",
            filetypes=[
                ("Lua / Luau files", "*.lua *.luau"),
                ("All files", "*.*"),
            ],
            initialdir=str(ROOT / "samples" if (ROOT / "samples").exists() else ROOT),
        )
        root.destroy()
        if path:
            return Path(path).resolve()
        return None
    except Exception:
        pass

    # Console fallback for Linux servers / environments without Tk.
    print("\nNo graphical file picker is available.")
    print("Enter the path to a .lua/.luau file (or press Enter to cancel).")
    raw = input("> ").strip().strip('"')
    if not raw:
        return None
    return Path(raw).expanduser().resolve()


def has_luau_runtime() -> bool:
    name = "luau.exe" if os.name == "nt" else "luau"
    return (BIN / name).is_file() or shutil.which(name) is not None


def build_runtime() -> bool:
    print("\n[*] Patched Luau runtime is missing.")
    print("    The full Luraph pipeline needs the bundled runtime.")
    answer = input("Build it automatically now? [Y/n]: ").strip().lower()
    if answer not in ("", "y", "yes"):
        return False

    cmd = [sys.executable, str(ROOT / "deobf" / "build_luau.py")]
    print("[*] Building Luau runtime...")
    try:
        subprocess.run(cmd, cwd=ROOT, check=True)
    except subprocess.CalledProcessError as exc:
        print(f"[!] Luau build failed with exit code {exc.returncode}.")
        return False
    return has_luau_runtime()


def output_path_for(src: Path) -> Path:
    # Keep source untouched. If the selected source is already named
    # deobfuscated.lua, avoid overwriting it.
    target = src.with_name("deobfuscated.lua")
    if target.resolve() == src.resolve():
        target = src.with_name("deobfuscated_new.lua")
    return target


def main() -> int:
    print("=" * 64)
    print("        Luau / Luraph v15 One-Click Deobfuscator")
    print("=" * 64)

    if not DEOB.is_file():
        print(f"[!] Missing deobfuscator: {DEOB}")
        return 1

    src = choose_file()
    if src is None:
        print("[i] Cancelled.")
        return 0
    if not src.is_file():
        print(f"[!] File not found: {src}")
        return 1
    if src.suffix.lower() not in {".lua", ".luau"}:
        print("[!] Please select a .lua or .luau file.")
        return 1

    # Force the bundled pipeline to have its runtime ready before invoking it.
    if not has_luau_runtime():
        if not build_runtime():
            print("[!] Cannot continue without Luau runtime.")
            print("    You can also build it manually with:")
            print("    python deobf/build_luau.py")
            return 1

    out = output_path_for(src)
    print(f"\n[*] Input : {src}")
    print(f"[*] Output: {out}")
    print("[*] Detecting obfuscator and running the normal devirtualization pipeline...\n")

    cmd = [
        sys.executable,
        str(DEOB),
        str(src),
        "--output",
        str(out),
    ]
    try:
        proc = subprocess.run(cmd, cwd=ROOT)
    except KeyboardInterrupt:
        print("\n[!] Cancelled by user.")
        return 130

    if proc.returncode != 0:
        print(f"\n[!] Deobfuscation failed (exit code {proc.returncode}).")
        return proc.returncode

    if out.is_file():
        print("\n[+] Done!")
        print(f"[+] Deobfuscated file: {out}")
        print("[+] The original input was not modified.")
        return 0

    print("\n[!] Pipeline finished but the expected output was not created.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
