# One-Click Luraph v15 Deobfuscator

## Windows
Double-click `run.bat`.

A file picker opens. Select the `.lua` / `.luau` file you want to process.
The tool automatically runs the bundled detector/devirtualizer and writes:

```text
deobfuscated.lua
```

next to the selected input file. The original input is never overwritten.

## Linux / macOS
Run:

```bash
./run.sh
```

The same picker/console fallback and output behavior are used.

## First run
The project needs a patched Luau runtime for the complete pipeline. If it is
missing, the launcher offers to build it automatically using:

```bash
python deobf/build_luau.py
```

The build requires Git, CMake and a C++ compiler.

## Output

For example:

```text
my_script.lua
 deobfuscated.lua
```

For a script that is already named `deobfuscated.lua`, the launcher writes
`deobfuscated_new.lua` so it cannot overwrite the selected source.
