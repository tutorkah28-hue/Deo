#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"

if command -v python3 >/dev/null 2>&1; then
    exec python3 launcher.py "$@"
elif command -v python >/dev/null 2>&1; then
    exec python launcher.py "$@"
else
    echo "[!] Python 3 was not found."
    echo "    Install Python 3 and run this script again."
    exit 1
fi
