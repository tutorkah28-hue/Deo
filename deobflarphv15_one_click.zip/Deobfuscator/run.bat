@echo off
setlocal
cd /d "%~dp0"

title Luraph v15 One-Click Deobfuscator

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 launcher.py
    set "RC=%errorlevel%"
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        python launcher.py
        set "RC=%errorlevel%"
    ) else (
        echo [!] Python 3 was not found.
        echo     Install Python 3 and run this file again.
        set "RC=1"
    )
)

echo.
if not "%RC%"=="0" echo [!] Finished with an error.
if "%RC%"=="0" echo [OK] Finished successfully.
pause
exit /b %RC%
